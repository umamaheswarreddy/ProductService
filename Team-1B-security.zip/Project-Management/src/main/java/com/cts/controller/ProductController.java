package com.cts.controller;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Product;
import com.cts.entity.Vendor;
import com.cts.service.ProductService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	private ProductService service;

	@GetMapping("/all")
	public List<Product> getAll() {

		return service.getProducts();
	}

	@GetMapping("/{productId}")
	public Optional<Product> getById(@PathVariable int productId) {
		return service.getProductById(productId);
	}

//	@RequestMapping(method = RequestMethod.POST, value = "/add")
	@PostMapping(value = "/add")
	public void addProduct(@Valid @RequestBody Product product) {
		service.addProduct(product);
	}

//	@RequestMapping(method = RequestMethod.PUT, value = "/update/{productId}")
	@PutMapping(value = "/update/{productId}")
	public void updateProduct(@RequestBody Product product, @PathVariable int productId) {
		service.updateProduct(product, productId);
	}

	@RequestMapping("/dashboard/feign/vendors")
	@HystrixCommand(fallbackMethod = "tolerence")
	public List<Product> findPeers() {
		return service.getAll();
	}

	public Collection<Vendor> tolerence() {
		return Arrays.asList(new Vendor(500, "df", "dsf", "7416565985", "maheshuma@gmail.com"),
				new Vendor(501, "df", "dsf", "7416565985", "maheshuma@gmail.com"));
	}

//	 @RequestMapping(method = RequestMethod.GET,value="/dashboard/feign/{vendorId}")
//	   public Vendor findme(@PathVariable Long vendorId){
//	      return service.getVendorById(vendorId);
//	   }

//	@GetMapping("/{productName}")
//	Product searchByName(@PathVariable String productName){
//		return service.searchByName(productName);
//	}

//	@RequestMapping(method = RequestMethod.DELETE, value = "/delete/{productId}")
	@DeleteMapping(value = "/{productId}")
	public void deleteProductById(@PathVariable int productId) {
		service.deleteProduct(productId);
	}

//	@GetMapping(value="/vendor/{vendorId}")
//	List<Product> getProductsByVendorId(@PathVariable Long vendorId){
//		return service.getProductByVendorId(vendorId);
//	}
	@GetMapping("/default")
	@HystrixCommand(fallbackMethod = "getAll")
	public List<Product> retrieveConfiguration() {
		throw new RuntimeException("Not available");
	}

}