package com.cts.service;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cts.entity.Product;
import com.cts.repository.ProductManagementRepository;


@RunWith(MockitoJUnitRunner.Silent.class)
public class ProductServiceTest {
	
	@Mock
	private ProductManagementRepository repo;
	@SuppressWarnings("unchecked")
	@Test
	public void addProductTest(){
	      Product product=new Product(1,"Name","Description",1500,1);
	      
	      Mockito.lenient().when(repo.save(product)).thenReturn(product);	
	}
	@Test
	public void getProductByIdTest() {
		Product product=new Product(1,"Name","Description",1500,1);
		Mockito.lenient().when(repo.findById(1)).thenReturn(Optional.of(product));
	}
	
	@Test
	public void deleteProduct() {
		Product product=new Product(1,"Name","Description",1500,1);
		Mockito.lenient().when(repo.findById(1)).thenReturn(Optional.of(product));
		repo.deleteById(1);
	}
	
}